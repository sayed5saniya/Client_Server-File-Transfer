//File Sharing System
//Saniya Sayed and Nisha Jasoliya
//Server Side
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>


void child(int);

int main(int argc, char *argv[]){  
  int sd, client, pnum, status;
  struct sockaddr_in servAdd;      // The address of the client socket
  
 if(argc != 2){
    printf("Calling the model with the following port number: %s <Port Number>\n", argv[0]);
    exit(0);
  }
  if ((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
    fprintf(stderr, "Oops! Socket can't be created--\n");
    exit(1);
  }
  sd = socket(AF_INET, SOCK_STREAM, 0);
  servAdd.sin_family = AF_INET;
  servAdd.sin_addr.s_addr = htonl(INADDR_ANY);
  sscanf(argv[1], "%d", &pnum);
  servAdd.sin_port = htons((uint16_t)pnum);
  
  bind(sd, (struct sockaddr *) &servAdd, sizeof(servAdd));
  listen(sd, 5);

  while(1){
    client = accept(sd, NULL, NULL);
    printf("Received a client! You many now start transfer|chat\n\n");
    
    if(!fork())
      child(client);

    close(client);
    waitpid(0, &status, WNOHANG);
  }
}

void child(int sd){
	char msg[255];
    char fname[255];
        int n, pid;
        int fd,n1;

        char r[] = "You have 3 options\n1) get filename\n2) put filename\n3) quit\n"; 
        write(sd, r, sizeof(r));
    int client;
	pid=fork();
	if(pid){              
       while(1){
            if(n=read(sd, msg, 255)){
	        msg[n]='\0';
            printf("---Client------/%d: %s", getpid(), msg);
	        
	        char * token = strtok(msg, " ");
            char reply[255],flag[100];
            int count=0;
            char ack[50];
            if(!strcasecmp(msg, "quit")){
    	        kill(pid, SIGTERM);
                kill(getppid(), SIGTERM);
     	        exit(0);
	        }
            else if(!strcasecmp(token, "get")){
                    while (token != NULL)
                    {
                        if(count++==1)
                            strcpy(fname,token);
                         token = strtok (NULL, " ");
                    }
                    fname[strlen(fname)-1] = '\0';
                                      
                   fd = open(fname, O_RDONLY);
                   read(fd, reply, 100);
 
                      if(fd == -1){
                         strcpy(flag,"-----Sorry! The file doesn't exists-------\n"); 
                        write(1, flag, strlen(flag));
                        write(sd,"h",1);                        
                    }
                    else{
                        strcpy(flag,"-----The file has been succesfully transferred-----\n"); 
                        write(1, flag, strlen(flag));
                        write(sd, reply, strlen(reply));
                     }
                    
            }
            else if(!strcasecmp(token, "put")){    
                    while (token != NULL)
                    {
                        if(count++==1){
                            strcpy(fname,token);
                            break;
                          }
                         token = strtok (NULL, " ");
                    }
                    fname[strlen(fname)-1] = '\0';
                    
                    
                    n1=read(sd, reply, 255);
                    
                     if(n1 <= 1){
                         printf("-----Oops!-----\n");
                     }
                     else{
                          fd = open(fname,O_CREAT|O_WRONLY,0777); 
                          write(fd,reply,strlen(reply));
                          printf("File sucessfully downloaded\n");
                        }                     
            }
            else{
               strcpy(msg,"Can't process the request!!!---Try again--------");
               write(sd, msg, strlen(msg)+1);
            } 
            printf("\n");
	   }
      } 
    }
 }

