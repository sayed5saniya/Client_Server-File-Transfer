//File Sharing System
//Saniya Sayed and Nisha Jasoliya
//Client Side
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>

int main(int argc, char *argv[]){
  char msg[255];//the message
  char fname[255];//file name
  int server, pnumb, pid, n;//server, portnumber
  struct sockaddr_in servAdd;     // the adress of the server socket
  int fd,n1;
  char b;
 if(argc != 3){
    printf("The IP address and the Port Number is: %s <IP Address> <Port Number>\n", argv[0]);
    exit(0);
  }

  if ((server = socket(AF_INET, SOCK_STREAM, 0)) < 0){
     fprintf(stderr, "\n Oops! Can't create the server socket\n");
     exit(1);
  }

  servAdd.sin_family = AF_INET;
  sscanf(argv[2], "%d", &pnumb);
  servAdd.sin_port = htons((uint16_t)pnumb);

  if(inet_pton(AF_INET, argv[1], &servAdd.sin_addr) < 0){//to check if the network address was successfully converted
  fprintf(stderr, " inet_pton() isn't successfull\n");
  exit(2);
}

 if(connect(server, (struct sockaddr *) &servAdd, sizeof(servAdd))<0){
  fprintf(stderr, "connect() isn't successfull, exiting now\n");
  exit(3);
 }

  read(server, msg, 255);
  fprintf(stderr, "The following message has been received: %s\n", msg);

  pid=fork();

  if(pid)                          
     while(1)
      if(n=read(0, msg, 255)){

         msg[n]='\0';        
         write(server, msg, strlen(msg)+1);
        char * token = strtok(msg, " ");
        int count=0;
        char flag[100],reply[255],ack[50];
         if(!strcasecmp(msg, "quit\n")){
            kill(getppid(), SIGTERM);
            exit(0);
          }
         else if(!strcasecmp(token, "get")){
                        
                   while (token != NULL)
                    {
                        if(count++==1)
                            strcpy(fname,token);
                         token = strtok (NULL, " ");
                    }
                    fname[strlen(fname)-1] = '\0';                   
                    n1=read(server, reply, 255);
                                                              
                            if(n1 <= 1){
                                printf("Sorry! This file doesnt exists----Server Side\n");
                            }
                             else{
                                fd = open(fname,O_CREAT|O_WRONLY,0777);
                                write(fd,reply,strlen(reply));
                                printf("-----Successfull download of the file------\n");
                            }                     
               }
          else if(!strcasecmp(token, "put")){
                   while (token != NULL)
                    {
                        if(count++==1)
                            strcpy(fname,token);
                         token = strtok (NULL, " ");
                    }
                    fname[strlen(fname)-1] = '\0';

                    fd = open(fname, O_RDONLY);
                    n1=read(fd, reply, 255);

                     if(fd == -1){
                         strcpy(flag,"Sorry! This file doesnt exists----Client Side\n"); 
                        write(1, flag, strlen(flag));
                        write(server,"h",1);                        
                    }
                    else{
                        strcpy(flag,"-----Successfull transfer of the file------\n"); 
                        write(1, flag, strlen(flag));
                        write(server, reply, strlen(reply));
                     }                   
          }
          else {
                strcpy(flag,"------The request has been discarded-----Try Again----\n"); 
                   write(1, flag, strlen(flag));
            }
        printf("\n");
        }    
}

